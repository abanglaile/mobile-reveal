/**
 * This file contains all of the z-index values used throughout the math-input
 * component and its children.
 */

module.exports = {
    popover: 1,
    echo: 2,
    keypad: 1060,
};
