
const config = {
  // server_url: "http://39.108.85.119:3000",
  // server_url : "https://www.kmap.xin/klmanager",
  //server_url: "http://www.zhiqiu.pro/api",
  //server_url: "http://172.20.10.2:7001/api",
  // server_url: "http://www.zhiqiu.pro/api",
  //server_url: "http://172.20.10.3:7001/api",

  // appid : "wx6f3a777231ad1747",
  appid : "wx1dc40895f45755ba",
  redirect_uri : "http%3a%2f%2fwww.zhiqiu.pro%2fmobile-zq%2finvite",
  www_url : "http://www.zhiqiu.pro/mobile-reveal",
  server_url: "http://127.0.0.1:7001/api",
}
//配置常用参数
export default config; 